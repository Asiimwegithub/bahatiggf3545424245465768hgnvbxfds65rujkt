-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 12, 2020 at 02:31 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bahati`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `id` int(11) NOT NULL,
  `AdminUserName` varchar(255) NOT NULL,
  `AdminPassword` varchar(255) NOT NULL,
  `AdminEmailId` varchar(255) NOT NULL,
  `Is_Active` int(11) NOT NULL,
  `CreationDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`id`, `AdminUserName`, `AdminPassword`, `AdminEmailId`, `Is_Active`, `CreationDate`, `UpdationDate`) VALUES
(1, 'bahati', 'bahati', 'bahatijoseph313@gmail.com', 1, '2018-05-27 20:51:00', '2020-12-12 12:54:27');

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `id` int(11) NOT NULL,
  `CategoryName` varchar(200) NOT NULL,
  `Description` mediumtext NOT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Is_Active` varchar(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`id`, `CategoryName`, `Description`, `PostingDate`, `UpdationDate`, `Is_Active`) VALUES
(1, 'Bollywood', 'Bollywood News', '2018-06-06 13:28:09', '2019-09-02 11:16:12', '1'),
(2, 'Sports', 'Related to sports news', '2018-06-06 13:35:09', '2019-09-02 11:16:15', '1'),
(3, 'Entertainment', 'Entertainment related  News', '2018-06-14 08:32:58', '2019-09-02 11:16:18', '1'),
(4, 'Politics', 'Politics', '2018-06-22 18:46:09', '2019-09-02 11:16:21', '1'),
(5, 'Business', 'Business News', '2018-06-22 18:46:22', '2019-09-02 11:47:57', '1'),
(10, 'District News', 'District News lorem100', '2019-09-02 12:42:37', '2019-09-02 12:42:37', '1'),
(11, 'Social', 'Social', '2020-12-12 08:12:15', '2020-12-12 08:12:15', '1'),
(12, 'Economic', 'Economic', '2020-12-12 08:12:32', '2020-12-12 08:12:32', '1'),
(13, 'Celebrity', 'Celebrity Jazz', '2020-12-12 08:12:59', '2020-12-12 08:12:59', '1'),
(14, 'Celebrity', 'Celebrity Jazz', '2020-12-12 08:14:58', '2020-12-12 08:14:58', '1'),
(15, 'Celebrity', 'Celebrity Jazz', '2020-12-12 08:15:25', '2020-12-12 08:15:25', '1'),
(16, 'Celebrity', 'Celebrity Jazz', '2020-12-12 08:16:28', '2020-12-12 08:16:28', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tblcomments`
--

CREATE TABLE `tblcomments` (
  `id` int(11) NOT NULL,
  `postId` char(11) DEFAULT NULL,
  `name` varchar(120) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `comment` mediumtext DEFAULT NULL,
  `postingDate` timestamp NULL DEFAULT current_timestamp(),
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcomments`
--

INSERT INTO `tblcomments` (`id`, `postId`, `name`, `email`, `comment`, `postingDate`, `status`) VALUES
(4, '11', 'Sharon', 'sharon@gmail', 'Nice Article', '2020-12-09 10:43:28', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblpages`
--

CREATE TABLE `tblpages` (
  `id` int(11) NOT NULL,
  `PageName` varchar(200) DEFAULT NULL,
  `PageTitle` mediumtext DEFAULT NULL,
  `Description` longtext DEFAULT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpages`
--

INSERT INTO `tblpages` (`id`, `PageName`, `PageTitle`, `Description`, `PostingDate`, `UpdationDate`) VALUES
(1, 'aboutus', 'Readers Campus Post', '<p><span style=\"color: rgb(51, 51, 51); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 17.6px;\">The current understanding of a media company is based on the idea of a publisher or broadcaster producing or aggregating, bundling, and distributing content. In this scenario, the content creation mainly is done by professionals. However, with the advent of mobile devices and ubiquitous Internet access, users have been enabled to produce content themselves. This gave rise to a new form of media companies: the platform operators, who aggregate, manage, and distribute user-generated content. Based on a historical summary, this article delineates the characteristics of this new approach of content distribution, draws comparisons to the traditional media companies, derives implications for the media markets, and provides a definition for the term&nbsp;</span><i style=\"color: rgb(51, 51, 51); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 17.6px;\">media company</i><span style=\"color: rgb(51, 51, 51); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 17.6px;\">&nbsp;that is valid in both the online and offline world.</span></p><p><span style=\"color: rgb(51, 51, 51); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 17.6px;\">The current understanding of a media company is based on the idea of a publisher or broadcaster producing or aggregating, bundling, and distributing content. In this scenario, the content creation mainly is done by professionals. However, with the advent of mobile devices and ubiquitous Internet access, users have been enabled to produce content themselves. This gave rise to a new form of media companies: the platform operators, who aggregate, manage, and distribute user-generated content. Based on a historical summary, this article delineates the characteristics of this new approach of content distribution, draws comparisons to the traditional media companies, derives implications for the media markets, and provides a definition for the term&nbsp;</span><i style=\"color: rgb(51, 51, 51); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 17.6px;\">media company</i><span style=\"color: rgb(51, 51, 51); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 17.6px;\">&nbsp;that is valid in both the online and offline world.</span><span style=\"color: rgb(51, 51, 51); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 17.6px;\"><br></span><br></p>', '2018-06-30 21:01:03', '2020-12-12 07:59:42'),
(2, 'contactus', 'Contact Details', '<p><br></p><p><b>Address :&nbsp; </b>Nawhera Gloria</p><p><b>Phone Number : </b>+25687686365</p><p><b>Email -id : </b>gloria@gmail.com</p>', '2018-06-30 21:01:36', '2020-12-12 00:48:09');

-- --------------------------------------------------------

--
-- Table structure for table `tblposts`
--

CREATE TABLE `tblposts` (
  `id` int(11) NOT NULL,
  `PostTitle` longtext DEFAULT NULL,
  `CategoryId` int(11) DEFAULT NULL,
  `SubCategoryId` int(11) DEFAULT NULL,
  `PostDetails` longtext CHARACTER SET utf8 DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `Is_Active` int(1) NOT NULL,
  `PostUrl` mediumtext DEFAULT NULL,
  `PostImage` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblposts`
--

INSERT INTO `tblposts` (`id`, `PostTitle`, `CategoryId`, `SubCategoryId`, `PostDetails`, `PostingDate`, `UpdationDate`, `Is_Active`, `PostUrl`, `PostImage`) VALUES
(17, 'Does he think the world believes his blatant lies? Do mixing fact and fiction get him on to another level of support and respect?', 4, 6, '<p><strong style=\"margin: 0px; padding: 0px; outline-style: initial; outline-width: 0px; color: rgb(32, 32, 33); font-family: Merriweather, serif; font-size: 14.4px; background-color: rgb(248, 248, 248);\">President Museveni only listens to the international community especially the USA.&nbsp;</strong><span style=\"color: rgb(32, 32, 33); font-family: Merriweather, serif; font-size: 14.4px; background-color: rgb(248, 248, 248);\">&nbsp;Far from it, President Museveni is keener on his electorate, regional leaders and respects international leaders. He has been a trailblazer in international relations, peacekeeping and fighting terrorism on the African continent and beyond. However, he respects the sovereignty of nations. Bilateral and multilateral relations between Uganda and other nations are governed by mutual interest and integrity.&nbsp; In fact, he stated as soon as he came to power that Uganda was non-aligned in the context of the old cold war lines but was keen on mutual interests and benefit.</span><br style=\"margin: 0px; padding: 0px; outline-style: initial; outline-width: 0px; color: rgb(32, 32, 33); font-family: Merriweather, serif; font-size: 14.4px; background-color: rgb(248, 248, 248);\"><br style=\"margin: 0px; padding: 0px; outline-style: initial; outline-width: 0px; color: rgb(32, 32, 33); font-family: Merriweather, serif; font-size: 14.4px; background-color: rgb(248, 248, 248);\"><span style=\"color: rgb(32, 32, 33); font-family: Merriweather, serif; font-size: 14.4px; background-color: rgb(248, 248, 248);\">Kyagulanyi said that&nbsp;</span><strong style=\"margin: 0px; padding: 0px; outline-style: initial; outline-width: 0px; color: rgb(32, 32, 33); font-family: Merriweather, serif; font-size: 14.4px; background-color: rgb(248, 248, 248);\">the elections will not be free or fair</strong><span style=\"color: rgb(32, 32, 33); font-family: Merriweather, serif; font-size: 14.4px; background-color: rgb(248, 248, 248);\">&nbsp;- Participation in a pointless exercise renders the participant hopeless and indicates crass decision making. There are 12 nominated candidates in this election and if the purpose of Kyagulanyi was to protest, there would be no need to run his show. He could easily stay home and protest.&nbsp;</span><br></p>', '2020-12-11 23:48:21', '2020-12-11 23:49:52', 1, 'Does-he-think-the-world-believes-his-blatant-lies?-Do-mixing-fact-and-fiction-get-him-on-to-another-level-of-support-and-respect?', 'fef46aacf20e60c9d2a2ca7b53d2d54a.jpg'),
(18, 'Over 100 arrested for not wearing masks', 4, 5, '<p><span style=\"color: rgb(32, 32, 33); font-family: Merriweather, serif; font-size: 16px; background-color: rgb(248, 248, 248);\">The Kampala Metropolitan police spokesperson Patrick Onyango says Police mounted an operation in Kampala to arrest people who were not wearing masks and arcade managers who have relaxed on enforcing the SOPs.</span></p><p><strong style=\"margin: 0px; padding: 0px; outline-style: initial; outline-width: 0px; color: rgb(32, 32, 33); font-family: Merriweather, serif; font-size: 14.4px; background-color: rgb(248, 248, 248);\">Police is holding over 100 suspects who were arrested flouting the COVID-19 Standard Operating Procedures (SOPs) in Kampala central business district.</strong><span style=\"color: rgb(32, 32, 33); font-family: Merriweather, serif; font-size: 16px; background-color: rgb(248, 248, 248);\"><br></span><br></p>', '2020-12-11 23:52:00', NULL, 1, 'Over-100-arrested-for-not-wearing-masks', '9537e1b647232837f02e40aa190f82cejpeg'),
(19, '3 foreign journalists removed from Uganda', 4, 6, '<h1 style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 0.2em; outline-style: initial; outline-width: 0px; font-size: 2.8em; color: rgb(81, 81, 81); font-family: Merriweather, serif; background-color: rgb(248, 248, 248);\"><span style=\"color: rgb(32, 32, 33); font-size: 16px;\">Government spokesperson Ofwono Opondo said CBC Europe correspondent Margaret Evans, producer Lily Martin and videographer JeanFrancois Bisson were asked to leave for breaking visa terms.</span></h1><h1 style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 0.2em; outline-style: initial; outline-width: 0px; font-size: 2.8em; color: rgb(81, 81, 81); font-family: Merriweather, serif; background-color: rgb(248, 248, 248);\"><span style=\"color: rgb(32, 32, 33); font-size: 16px;\"><br></span>\"They applied for a tourist visa to go to Bwindi Impenetrable National Park in Kanungu district and then they were found in Sheraton Kampala Hotel doing stories about politics and COVID-19.<br style=\"margin: 0px; padding: 0px; outline-style: initial; outline-width: 0px; color: rgb(32, 32, 33); font-size: 14.4px;\"><br style=\"margin: 0px; padding: 0px; outline-style: initial; outline-width: 0px; color: rgb(32, 32, 33); font-size: 14.4px;\"><span style=\"color: rgb(32, 32, 33); font-size: 14.4px;\">To do so, you must declare you are coming to work as a journalist,\" he said.</span><br style=\"margin: 0px; padding: 0px; outline-style: initial; outline-width: 0px; color: rgb(32, 32, 33); font-size: 14.4px;\"><br style=\"margin: 0px; padding: 0px; outline-style: initial; outline-width: 0px; color: rgb(32, 32, 33); font-size: 14.4px;\"><span style=\"color: rgb(32, 32, 33); font-size: 14.4px;\">\"So we withdrew this pass and asked them to reapply for a journalist visa if they want to work as journalists in Uganda. If they do that, we shall grant them&nbsp;accreditation,\" Opondo stated.</span><br style=\"margin: 0px; padding: 0px; outline-style: initial; outline-width: 0px; color: rgb(32, 32, 33); font-size: 14.4px;\"><span style=\"color: rgb(32, 32, 33); font-size: 14.4px;\">He refuted their claim that they had been deported. \"Deportation and removal are legal terms in the laws of Uganda. With deportation, the court is the one which orders your deportation. In the same law, the minister or his authorised officer can order your removal, which is quicker and cheaper for both sides,\" he explained.</span><br></h1>', '2020-12-11 23:54:26', NULL, 1, '3-foreign-journalists-removed-from-Uganda', '405a55a41ae26bc63eb4765d18404417.jpg'),
(20, 'uena Pens Down Heartfelt Letter To Bebe Cool’s First Born, Allan After Finalizing Studies', 3, 4, '<p><span style=\"font-family: Arial, Helvetica, sans-serif; font-size: 15.2px;\">Singer Big Size Bebe Cool might have not managed to complete his studies but he truly knows the values of education. Bebe, a senior 6 drop out has proved this to the world by educating his first born, Allan Hendrick up to University.</span></p><p><span style=\"font-family: Arial, Helvetica, sans-serif; font-size: 15.2px;\">Good enough, Allan paid him back by not splashing tuition fee on city juicy babes and now he has successfully graduated. Allan, who is an upcoming artist has completed his studies at International University Kampala today.</span></p><p><span style=\"font-family: Arial, Helvetica, sans-serif; font-size: 15.2px;\">He is now a certified software Engineer! His&nbsp; step mum, Zuena Kirema couldn’t hide the happiness as he rushed to her&nbsp; Facebook page and posted;</span><span style=\"font-family: Arial, Helvetica, sans-serif; font-size: 15.2px;\"><br></span><span style=\"font-family: Arial, Helvetica, sans-serif; font-size: 15.2px;\"><br></span><br></p>', '2020-12-11 23:58:44', NULL, 1, 'uena-Pens-Down-Heartfelt-Letter-To-Bebe-Cool’s-First-Born,-Allan-After-Finalizing-Studies', '99ed5b0111ea35bd435cb3a94d3edea3.png'),
(21, 'Leverage on Trade finance solutions to grow your business – Michael Jjingo', 10, 9, '<p style=\"margin-bottom: 5px; padding: 10px 5px 10px 50px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 15.2px; line-height: inherit; font-family: Arial, Helvetica, sans-serif; vertical-align: baseline;\">“The goal of a successful trader is to make the best trades. Money is secondary”, Alexander Elder. Trade Finance is the financing of goods or services in a trade or a transaction, from a supplier through to the end buyer. Generally, trade finance supports trade, contract and project financing.</p><p style=\"margin-bottom: 5px; padding-right: 5px; padding-bottom: 10px; padding-left: 50px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 15.2px; line-height: inherit; font-family: Arial, Helvetica, sans-serif; vertical-align: baseline;\">Trade Finance entails a variety of financial instruments/ facility structures that can be used by an importer or exporter or contractor. These structures include: Pre-import and post-export Finance, Structured Commodity Finance, Invoice Finance (Discounting &amp; Factoring), Supply Chain Finance (Supplier, buyer, factor), Letters of Credit (LCs) and; Bonds &amp; Guarantees (Bid bonds, performance guarantees, advance payment guarantees, bank guarantees etc).</p>', '2020-12-12 00:00:49', NULL, 1, 'Leverage-on-Trade-finance-solutions-to-grow-your-business-–-Michael-Jjingo', '7c13e2471159451524c824f4c443a0af.png');

-- --------------------------------------------------------

--
-- Table structure for table `tblsubcategory`
--

CREATE TABLE `tblsubcategory` (
  `SubCategoryId` int(11) NOT NULL,
  `CategoryId` int(11) NOT NULL,
  `Subcategory` varchar(255) NOT NULL,
  `SubCatDescription` mediumtext NOT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Is_Active` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsubcategory`
--

INSERT INTO `tblsubcategory` (`SubCategoryId`, `CategoryId`, `Subcategory`, `SubCatDescription`, `PostingDate`, `UpdationDate`, `Is_Active`) VALUES
(3, 2, 'Football', 'Football', '2018-06-30 12:00:58', '2019-09-02 11:18:59', 1),
(4, 3, 'Television', 'TeleVision', '2018-06-30 21:59:22', '2019-09-02 11:19:04', 1),
(5, 4, 'National', 'National', '2018-06-30 22:04:29', '2019-09-02 11:19:09', 1),
(6, 4, 'International', 'International', '2018-06-30 22:04:43', '2019-09-02 11:19:16', 1),
(7, 4, 'India', 'India', '2018-06-30 22:08:42', '2019-09-02 11:19:22', 1),
(9, 10, 'Noakhali', 'all News', '2019-09-02 12:43:02', '2019-09-02 12:43:02', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcomments`
--
ALTER TABLE `tblcomments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblpages`
--
ALTER TABLE `tblpages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblposts`
--
ALTER TABLE `tblposts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblsubcategory`
--
ALTER TABLE `tblsubcategory`
  ADD PRIMARY KEY (`SubCategoryId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tblcomments`
--
ALTER TABLE `tblcomments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblpages`
--
ALTER TABLE `tblpages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblposts`
--
ALTER TABLE `tblposts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tblsubcategory`
--
ALTER TABLE `tblsubcategory`
  MODIFY `SubCategoryId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
